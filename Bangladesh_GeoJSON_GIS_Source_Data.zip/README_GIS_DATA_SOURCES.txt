================================================================================
BANGLADESH ADMINISTRATIVE GIS & GEOJSON SOURCE DATASET
================================================================================

This package contains the official geographic boundaries, polygon geometries, 
and centroid coordinates (Latitude & Longitude) for the People's Republic of Bangladesh.

--------------------------------------------------------------------------------
1. NATIONAL LEVEL (Level 0 / Level 1)
--------------------------------------------------------------------------------
- File: 1_National_Border/bangladesh_national_boundary.json
- Content: Complete outer administrative coastline and international borders.
- Standard Source: Bangladesh Bureau of Statistics (BBS) / Survey of Bangladesh (SOB) & GADM v4.1.

--------------------------------------------------------------------------------
2. DIVISION LEVEL (8 Administrative Divisions)
--------------------------------------------------------------------------------
- File: 2_Divisions/bangladesh_divisions_raw.json
- Content: Dhaka, Chattogram, Rajshahi, Khulna, Barishal, Sylhet, Rangpur, Mymensingh.

--------------------------------------------------------------------------------
3. DISTRICT LEVEL (64 Districts / Zilas)
--------------------------------------------------------------------------------
- File: 3_Districts_64/bangladesh_64_districts_boundaries_centroids.json
- File: 3_Districts_64/bd_districts_geo.js
- Content: Polygons, bounding boxes, and district HQ centroid GPS coordinates (Lat/Long).

--------------------------------------------------------------------------------
4. THANA / UPAZILA LEVEL (495+ Sub-Districts)
--------------------------------------------------------------------------------
- File: 4_Thanas_Upazilas_495/bangladesh_495_upazilas_boundaries_centroids.json
- File: 4_Thanas_Upazilas_495/bd_thanas_geo.js
- Content: Complete polygon coordinates & geographic center coordinates (Centroids)
           for all 495+ administrative Upazilas / Thanas across Bangladesh.

--------------------------------------------------------------------------------
DATA STANDARDS & SPATIAL REFERENCE:
- Coordinate Reference System (CRS): WGS 84 (EPSG:4326)
- Coordinates format: [Longitude, Latitude] in GeoJSON standards / [Lat, Lng] in JS.
- Verification: Validated against OpenStreetMap (OSM) Bangladesh Administrative Boundaries.
================================================================================
